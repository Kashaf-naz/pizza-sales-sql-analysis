-- Join relevant tables to find the category-wise distribution of pizzas.

select category , count(name) as total_pizzas from pizza_types group by category;