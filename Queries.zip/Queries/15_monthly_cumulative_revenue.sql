-- find monthly cumulative revenue
WITH monthly_sales AS (
    SELECT 
        DATE_FORMAT(o.order_date, '%Y-%m') AS month,
        ROUND(SUM(od.quantity * p.price), 2) AS monthly_revenue
    FROM order_details od
    JOIN pizzas p 
        ON od.pizza_id = p.pizza_id
    JOIN orders o 
        ON o.order_id = od.order_id
    GROUP BY month
)
SELECT 
    month,
    monthly_revenue,
    ROUND(
        SUM(monthly_revenue) OVER (ORDER BY month),
    2) AS cumulative_revenue
FROM monthly_sales
ORDER BY month;
