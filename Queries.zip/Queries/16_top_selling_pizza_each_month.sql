-- What is the top-selling pizza (by quantity) for each month?
With monthly_sales AS(
select date_format(orders.order_date, '%Y-%m') as month,
pizza_types.pizza_type_id, 
pizza_types.name, 
sum(order_details.quantity) as total_qty
from orders join order_details on order_details.order_id = orders.order_id
join pizzas on order_details.pizza_id = pizzas.pizza_id
join pizza_types on pizza_types.pizza_type_id = pizzas.pizza_type_id
group by month, pizza_types.pizza_type_id, pizza_types.name),

ranked_sales AS (
    SELECT 
        *, 
        RANK() OVER (PARTITION BY month ORDER BY total_qty DESC) AS rnk
    FROM monthly_sales
)
SELECT month, name AS top_pizza, total_qty
FROM ranked_sales
WHERE rnk = 1
ORDER BY month;